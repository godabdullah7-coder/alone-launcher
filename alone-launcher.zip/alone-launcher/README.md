# ALONE LAUNCHER (pure Rust, Android)

No Java or Kotlin: the app is Rust (egui) running in a NativeActivity.

- `src/`      alone-core: controls import/export/validate, Mojang versions + verified downloads, Modrinth search/install, launch command.
- `app/`      the Android app (landscape): sidebar with Home, Create new, Library, Discover (Modrinth), Themes (6 blue themes), Controls editor (drag, resize, import/export JSON, save), Settings. Your logo is the app icon.

## Build the APK
1. Install Rust, Android SDK + NDK (set ANDROID_HOME and ANDROID_NDK_ROOT).
2. `rustup target add aarch64-linux-android && cargo install cargo-apk`
3. `cd app && cargo apk build --release` (APK is in `target/release/apk/`; add your own signing key in `[package.metadata.android.signing.release]` to install it).
4. Quick test of the controls logic: `cargo test` in the top folder.

## Not done yet
- Mod loaders (Fabric, Forge, NeoForge, Quilt, OptiFine): shown as "soon"; only Vanilla installs.
- Starting the game itself, Microsoft login, a file-picker button for controls (paste JSON works), wallpapers.
- The layout follows the structure of the Aerix screenshots, but the code, colours and artwork are my own.

Written without a Rust toolchain here: if `cargo` shows an error, send it to me.
