//! Mojang manifest, version metadata and verified downloads.
use serde::Deserialize;
use sha1::{Digest, Sha1};
use std::{fs, path::Path};

pub const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const ASSET_URL: &str = "https://resources.download.minecraft.net";

#[derive(Deserialize, Debug, Clone)]
pub struct VersionEntry {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub url: String,
}
#[derive(Deserialize, Debug)]
pub struct Manifest { pub versions: Vec<VersionEntry> }

#[derive(Deserialize, Debug)]
pub struct FileRef { pub url: String, #[serde(default)] pub sha1: String }
#[derive(Deserialize, Debug)]
pub struct AssetIndex { pub id: String, pub url: String, #[serde(default)] pub sha1: String }
#[derive(Deserialize, Debug)]
pub struct Downloads { pub client: FileRef }
#[derive(Deserialize, Debug)]
pub struct Artifact { pub path: String, pub url: String, #[serde(default)] pub sha1: String }
#[derive(Deserialize, Debug)]
pub struct LibDownloads { pub artifact: Option<Artifact> }
#[derive(Deserialize, Debug)]
pub struct OsRule { pub name: Option<String> }
#[derive(Deserialize, Debug)]
pub struct Rule { pub action: String, pub os: Option<OsRule> }
#[derive(Deserialize, Debug)]
pub struct Library { pub downloads: Option<LibDownloads>, pub rules: Option<Vec<Rule>> }

#[derive(Deserialize, Debug)]
pub struct VersionMeta {
    pub id: String,
    #[serde(rename = "mainClass")]
    pub main_class: String,
    #[serde(rename = "assetIndex")]
    pub asset_index: AssetIndex,
    pub downloads: Downloads,
    pub libraries: Vec<Library>,
    pub arguments: Option<serde_json::Value>,
    #[serde(rename = "minecraftArguments")]
    pub legacy_args: Option<String>,
}

pub fn fetch_manifest() -> Result<Manifest, String> {
    reqwest::blocking::get(MANIFEST_URL).map_err(|e| e.to_string())?
        .json().map_err(|e| e.to_string())
}

pub fn fetch_meta(entry: &VersionEntry) -> Result<VersionMeta, String> {
    reqwest::blocking::get(&entry.url).map_err(|e| e.to_string())?
        .json().map_err(|e| e.to_string())
}

/// Android counts as Linux for library rules.
pub fn lib_allowed(rules: &Option<Vec<Rule>>) -> bool {
    let Some(rs) = rules else { return true };
    let mut ok = false;
    for r in rs {
        let applies = r.os.as_ref().map_or(true, |o| o.name.as_deref() == Some("linux"));
        if applies { ok = r.action == "allow"; }
    }
    ok
}

/// Download a file and verify its SHA-1. Skips the download if it already matches.
pub fn download_verified(url: &str, dest: &Path, sha1_hex: &str) -> Result<(), String> {
    if dest.exists() {
        if sha1_hex.is_empty() { return Ok(()); }
        if let Ok(b) = fs::read(dest) {
            if format!("{:x}", Sha1::digest(&b)) == sha1_hex { return Ok(()); }
        }
    }
    let bytes = reqwest::blocking::get(url).map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .bytes().map_err(|e| e.to_string())?;
    if !sha1_hex.is_empty() && format!("{:x}", Sha1::digest(&bytes)) != sha1_hex {
        return Err(format!("checksum mismatch: {url}"));
    }
    if let Some(p) = dest.parent() { fs::create_dir_all(p).map_err(|e| e.to_string())?; }
    fs::write(dest, &bytes).map_err(|e| e.to_string())
}

/// Install client jar, libraries and assets under `root`. `progress(done, total)`.
pub fn install(meta: &VersionMeta, root: &Path, progress: &dyn Fn(usize, usize)) -> Result<(), String> {
    let jar = root.join("versions").join(&meta.id).join(format!("{}.jar", meta.id));
    download_verified(&meta.downloads.client.url, &jar, &meta.downloads.client.sha1)?;

    let libs: Vec<&Artifact> = meta.libraries.iter()
        .filter(|l| lib_allowed(&l.rules))
        .filter_map(|l| l.downloads.as_ref()?.artifact.as_ref()).collect();

    let idx_path = root.join("assets/indexes").join(format!("{}.json", meta.asset_index.id));
    download_verified(&meta.asset_index.url, &idx_path, &meta.asset_index.sha1)?;
    let idx: serde_json::Value = serde_json::from_slice(&fs::read(&idx_path).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    let objects: Vec<String> = idx["objects"].as_object().into_iter().flatten()
        .filter_map(|(_, v)| v["hash"].as_str().map(String::from)).collect();

    let total = libs.len() + objects.len();
    let mut done = 0;
    for a in libs {
        download_verified(&a.url, &root.join("libraries").join(&a.path), &a.sha1)?;
        done += 1; progress(done, total);
    }
    for h in objects {
        let url = format!("{ASSET_URL}/{}/{h}", &h[..2]);
        download_verified(&url, &root.join("assets/objects").join(&h[..2]).join(&h), &h)?;
        done += 1; progress(done, total);
    }
    Ok(())
}
