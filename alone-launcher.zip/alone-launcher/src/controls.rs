//! Custom controls: import / export / validate / save. Also reads the layout
//! format used by the web prototype (a plain array of {label,x,y,s}).
use serde::{Deserialize, Serialize};
use std::{fs, path::{Path, PathBuf}};

pub const MAX_BYTES: usize = 256 * 1024;
pub const MAX_BUTTONS: usize = 80;

fn d_name() -> String { "My controls".into() }
fn d_op() -> f32 { 0.8 }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ControlButton {
    pub label: String,
    /// Position in percent of the screen (0..100).
    pub x: f32,
    pub y: f32,
    #[serde(alias = "s")]
    pub size: f32,
    /// Action this button triggers, e.g. "jump", "attack", "key_w".
    #[serde(default)]
    pub key: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ControlLayout {
    #[serde(default = "d_name")]
    pub name: String,
    #[serde(default = "d_op")]
    pub opacity: f32,
    pub buttons: Vec<ControlButton>,
}

fn clean(s: &str, max: usize) -> String {
    s.chars().filter(|c| !c.is_control()).take(max).collect()
}

fn sanitize(l: &mut ControlLayout) -> Result<(), String> {
    if l.buttons.is_empty() { return Err("layout has no buttons".into()); }
    if l.buttons.len() > MAX_BUTTONS { return Err(format!("max {MAX_BUTTONS} buttons")); }
    if !l.opacity.is_finite() { l.opacity = d_op(); }
    l.opacity = l.opacity.clamp(0.2, 1.0);
    l.name = clean(&l.name, 40);
    for b in &mut l.buttons {
        if !(b.x.is_finite() && b.y.is_finite() && b.size.is_finite()) {
            return Err("button has an invalid number".into());
        }
        b.x = b.x.clamp(0.0, 100.0);
        b.y = b.y.clamp(0.0, 100.0);
        b.size = b.size.clamp(20.0, 160.0);
        b.label = clean(&b.label, 8);
        b.key = b.key.chars().filter(|c| c.is_ascii_alphanumeric() || *c == '_').take(24).collect();
    }
    Ok(())
}

/// Parse and validate a layout from JSON text (file contents or pasted text).
pub fn import(text: &str) -> Result<ControlLayout, String> {
    if text.len() > MAX_BYTES { return Err("file too large".into()); }
    let mut layout = match serde_json::from_str::<ControlLayout>(text) {
        Ok(l) => l,
        Err(_) => {
            let buttons = serde_json::from_str::<Vec<ControlButton>>(text)
                .map_err(|e| format!("invalid layout: {e}"))?;
            ControlLayout { name: d_name(), opacity: d_op(), buttons }
        }
    };
    sanitize(&mut layout)?;
    Ok(layout)
}

pub fn export(l: &ControlLayout) -> String {
    serde_json::to_string_pretty(l).unwrap_or_default()
}

fn file_for(dir: &Path, name: &str) -> PathBuf {
    let mut n: String = name.chars().filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_').collect();
    if n.is_empty() { n = "layout".into(); }
    dir.join(format!("{n}.json"))
}

pub fn save(dir: &Path, l: &ControlLayout) -> Result<PathBuf, String> {
    fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    let p = file_for(dir, &l.name);
    fs::write(&p, export(l)).map_err(|e| e.to_string())?;
    Ok(p)
}

pub fn load(dir: &Path, name: &str) -> Result<ControlLayout, String> {
    let t = fs::read_to_string(file_for(dir, name)).map_err(|e| e.to_string())?;
    import(&t)
}

pub fn list(dir: &Path) -> Vec<String> {
    let mut v: Vec<String> = fs::read_dir(dir).into_iter().flatten().flatten()
        .filter_map(|e| e.path().file_stem().map(|s| s.to_string_lossy().into_owned()))
        .collect();
    v.sort();
    v
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reads_prototype_array() {
        let l = import(r#"[{"label":"Jump","x":88,"y":76,"s":56}]"#).unwrap();
        assert_eq!(l.buttons[0].size, 56.0);
    }
    #[test]
    fn clamps_values() {
        let l = import(r#"{"buttons":[{"label":"A","x":500,"y":-4,"size":9999}]}"#).unwrap();
        assert_eq!((l.buttons[0].x, l.buttons[0].y, l.buttons[0].size), (100.0, 0.0, 160.0));
    }
    #[test]
    fn rejects_garbage() {
        assert!(import("not json").is_err());
        assert!(import(r#"{"buttons":[]}"#).is_err());
    }
}
