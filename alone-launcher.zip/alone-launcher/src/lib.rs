//! ALONE LAUNCHER core: custom controls, versions, Modrinth, launch command.
pub mod controls;
pub mod launch;
pub mod modrinth;
pub mod versions;
