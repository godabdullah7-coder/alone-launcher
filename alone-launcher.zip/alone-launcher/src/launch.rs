//! Builds the java command line for an installed version.
use crate::versions::{lib_allowed, VersionMeta};
use std::{collections::HashMap, path::PathBuf};

pub struct LaunchCtx {
    pub java: String,
    pub root: PathBuf,
    pub game_dir: PathBuf,
    pub natives_dir: PathBuf,
    pub username: String,
    pub uuid: String,
    pub access_token: String,
    pub ram_mb: u32,
}

fn strings_in(v: Option<&serde_json::Value>) -> Vec<String> {
    v.and_then(|a| a.as_array()).into_iter().flatten()
        .filter_map(|x| x.as_str().map(String::from)).collect()
}

fn fill(args: Vec<String>, vars: &HashMap<&str, String>) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let mut a = args[i].clone();
        for (k, v) in vars { a = a.replace(&format!("${{{k}}}"), v); }
        if a.contains("${") {
            // unknown placeholder: drop it, and its flag if it has one
            if out.last().map_or(false, |l: &String| l.starts_with("--")) { out.pop(); }
        } else {
            out.push(a);
        }
        i += 1;
    }
    out
}

pub fn build_command(meta: &VersionMeta, c: &LaunchCtx) -> Vec<String> {
    let sep = ":";
    let mut cp: Vec<String> = meta.libraries.iter()
        .filter(|l| lib_allowed(&l.rules))
        .filter_map(|l| l.downloads.as_ref()?.artifact.as_ref())
        .map(|a| c.root.join("libraries").join(&a.path).to_string_lossy().into_owned()).collect();
    cp.push(c.root.join("versions").join(&meta.id).join(format!("{}.jar", meta.id)).to_string_lossy().into_owned());

    let mut vars: HashMap<&str, String> = HashMap::new();
    vars.insert("auth_player_name", c.username.clone());
    vars.insert("version_name", meta.id.clone());
    vars.insert("game_directory", c.game_dir.to_string_lossy().into_owned());
    vars.insert("assets_root", c.root.join("assets").to_string_lossy().into_owned());
    vars.insert("assets_index_name", meta.asset_index.id.clone());
    vars.insert("auth_uuid", c.uuid.clone());
    vars.insert("auth_access_token", c.access_token.clone());
    vars.insert("user_type", "msa".into());
    vars.insert("version_type", "release".into());
    vars.insert("classpath", cp.join(sep));
    vars.insert("natives_directory", c.natives_dir.to_string_lossy().into_owned());
    vars.insert("launcher_name", "ALONE".into());
    vars.insert("launcher_version", "0.1".into());

    let (jvm, game) = match (&meta.arguments, &meta.legacy_args) {
        (Some(a), _) => (strings_in(a.get("jvm")), strings_in(a.get("game"))),
        (None, Some(s)) => (
            vec!["-Djava.library.path=${natives_directory}".into(), "-cp".into(), "${classpath}".into()],
            s.split_whitespace().map(String::from).collect(),
        ),
        _ => (vec![], vec![]),
    };

    let mut cmd = vec![c.java.clone(), format!("-Xmx{}M", c.ram_mb), format!("-Xms{}M", (c.ram_mb / 2).max(512))];
    cmd.extend(fill(jvm, &vars));
    cmd.push(meta.main_class.clone());
    cmd.extend(fill(game, &vars));
    cmd
}
