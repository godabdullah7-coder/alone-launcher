//! Modrinth: search and install mods, resource packs and shaders (https://modrinth.com).
use crate::versions::download_verified;
use serde::Deserialize;
use std::path::Path;

const API: &str = "https://api.modrinth.com/v2";

#[derive(Deserialize, Clone, Debug)]
pub struct Project {
    pub slug: String,
    pub title: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub downloads: u64,
    #[serde(default)]
    pub categories: Vec<String>,
}
#[derive(Deserialize)]
struct SearchResult { hits: Vec<Project> }
#[derive(Deserialize)]
struct Hashes { sha1: String }
#[derive(Deserialize)]
struct VFile { url: String, filename: String, #[serde(default)] primary: bool, hashes: Hashes }
#[derive(Deserialize)]
struct Version { files: Vec<VFile> }

fn client() -> Result<reqwest::blocking::Client, String> {
    // Modrinth asks every app to identify itself.
    reqwest::blocking::Client::builder()
        .user_agent("alone-launcher/0.1")
        .build()
        .map_err(|e| e.to_string())
}

/// `project_type`: "mod", "resourcepack" or "shader".
pub fn search(query: &str, project_type: &str, offset: u32, limit: u32) -> Result<Vec<Project>, String> {
    let facets = format!("[[\"project_type:{project_type}\"]]");
    let (lim, off) = (limit.to_string(), offset.to_string());
    let r: SearchResult = client()?
        .get(format!("{API}/search"))
        .query(&[("query", query), ("facets", facets.as_str()), ("limit", lim.as_str()), ("offset", off.as_str())])
        .send().map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json().map_err(|e| e.to_string())?;
    Ok(r.hits)
}

/// Download the newest file for `mc_version` (and `loader`, when not empty) into `dir`.
pub fn install(slug: &str, mc_version: &str, loader: &str, dir: &Path) -> Result<String, String> {
    if slug.is_empty() || !slug.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_') {
        return Err("bad project id".into());
    }
    let gv = format!("[\"{mc_version}\"]");
    let ld = format!("[\"{loader}\"]");
    let mut q = vec![("game_versions", gv.as_str())];
    if !loader.is_empty() { q.push(("loaders", ld.as_str())); }
    let versions: Vec<Version> = client()?
        .get(format!("{API}/project/{slug}/version"))
        .query(&q)
        .send().map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json().map_err(|e| e.to_string())?;
    let v = versions.first().ok_or("no version for this Minecraft version")?;
    let f = v.files.iter().find(|f| f.primary).or(v.files.first()).ok_or("no file")?;
    let name = Path::new(&f.filename).file_name().ok_or("bad file name")?.to_string_lossy().into_owned();
    download_verified(&f.url, &dir.join(&name), &f.hashes.sha1)?;
    Ok(name)
}
