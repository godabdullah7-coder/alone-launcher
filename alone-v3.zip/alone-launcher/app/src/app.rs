//! ALONE LAUNCHER: sidebar UI (Home, Create new, Library, Discover, Themes, Controls, Settings).
//! All Rust (egui). Blue themes.
use eframe::egui::{self, Color32, FontId, Frame, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use alone_core::controls::{self, ControlButton, ControlLayout};
use alone_core::modrinth::{self, Project};
use alone_core::versions::{self, VersionEntry};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

type Shared<T> = Arc<Mutex<T>>;

const TEXT: Color32 = Color32::from_rgb(234, 246, 230);
const DARK: Color32 = Color32::from_rgb(10, 26, 6);

#[derive(Clone, Copy)]
struct Pal { bg: Color32, bg2: Color32, card: Color32, accent: Color32, accent2: Color32 }

const fn rgb(h: u32) -> Color32 { Color32::from_rgb((h >> 16) as u8, (h >> 8) as u8, h as u8) }

fn pal_of(_i: usize) -> Pal {
    Pal { bg: rgb(0x0A1C10), bg2: rgb(0x1B3A1E), card: rgb(0x0F1F14), accent: rgb(0x84CC16), accent2: rgb(0xB6F23A) }
}

// wallpaper name, subtitle
const WALLPAPERS: [(&str, &str); 9] = [
    ("Pine Lake", "Mountain lake"),
    ("Golden Peak", "Sunrise waterfall"),
    ("Cherry Lagoon", "Pink cherry trees"),
    ("Fishing Falls", "Waterfall camp"),
    ("Lantern Lake", "Sunset village"),
    ("Aurora Cabin", "Northern lights"),
    ("Glow Cave", "Glowing mushrooms"),
    ("Nether Dive", "Official art"),
    ("Spring Friends", "Official art"),
];
fn wp_full(i: usize) -> &'static [u8] {
    match i {
        0 => &include_bytes!("../../assets/wp/wp0.jpg")[..],
        1 => &include_bytes!("../../assets/wp/wp1.jpg")[..],
        2 => &include_bytes!("../../assets/wp/wp2.jpg")[..],
        3 => &include_bytes!("../../assets/wp/wp3.jpg")[..],
        4 => &include_bytes!("../../assets/wp/wp4.jpg")[..],
        5 => &include_bytes!("../../assets/wp/wp5.jpg")[..],
        6 => &include_bytes!("../../assets/wp/wp6.jpg")[..],
        7 => &include_bytes!("../../assets/wp/wp7.jpg")[..],
        8 => &include_bytes!("../../assets/wp/wp8.jpg")[..],
        _ => &[],
    }
}
fn wp_thumb(i: usize) -> &'static [u8] {
    match i {
        0 => &include_bytes!("../../assets/wp/wp0_t.jpg")[..],
        1 => &include_bytes!("../../assets/wp/wp1_t.jpg")[..],
        2 => &include_bytes!("../../assets/wp/wp2_t.jpg")[..],
        3 => &include_bytes!("../../assets/wp/wp3_t.jpg")[..],
        4 => &include_bytes!("../../assets/wp/wp4_t.jpg")[..],
        5 => &include_bytes!("../../assets/wp/wp5_t.jpg")[..],
        6 => &include_bytes!("../../assets/wp/wp6_t.jpg")[..],
        7 => &include_bytes!("../../assets/wp/wp7_t.jpg")[..],
        8 => &include_bytes!("../../assets/wp/wp8_t.jpg")[..],
        _ => &[],
    }
}

fn decode_tex(ctx: &egui::Context, name: &str, bytes: &[u8]) -> Option<egui::TextureHandle> {
    let img = image::load_from_memory(bytes).ok()?.to_rgba8();
    let size = [img.width() as usize, img.height() as usize];
    let ci = egui::ColorImage::from_rgba_unmultiplied(size, img.as_raw());
    Some(ctx.load_texture(name, ci, egui::TextureOptions::LINEAR))
}

// name, description, installable now
const LOADERS: [(&str, &str, bool); 7] = [
    ("Vanilla", "The original", true), ("Fabric", "Lightweight mods", false),
    ("Forge", "Recommended", false), ("NeoForge", "Modern Forge", false),
    ("Quilt", "Fabric alternative", false), ("OptiFine", "Performance", false),
    ("Legacy Fabric", "1.14 and older", false),
];
const RENDERERS: [(&str, &str); 5] = [
    ("Auto (Smart Pick)", "Recommended"), ("MobileGlues", "OpenGL ES, 1.17+"),
    ("NG-GL4ES", "Older versions"), ("GL4ES", "Classic"), ("Freedreno", "Adreno GPUs"),
];
const STABS: [&str; 5] = ["Renderer", "Game", "Java", "Launcher", "About"];
const DTYPES: [(&str, &str); 3] = [("Mods", "mod"), ("Resource Packs", "resourcepack"), ("Shaders", "shader")];
const KINDS: [(&str, &str); 4] = [("Release", "release"), ("Snapshot", "snapshot"), ("Old beta", "old_beta"), ("Old alpha", "old_alpha")];

#[derive(PartialEq, Clone, Copy)]
enum Screen { Home, Create, Library, Discover, Themes, Controls, Settings }

#[derive(Clone, Serialize, Deserialize)]
struct Instance { name: String, mc: String, loader: String, #[serde(default)] pinned: bool }

#[derive(Serialize, Deserialize, Default)]
struct Saved {
    instances: Vec<Instance>,
    active: Option<usize>,
    ram_mb: u32,
    jre: u8,
    theme: usize,
    user: String,
    #[serde(default)]
    renderer: usize,
    #[serde(default)]
    wallpaper: usize,
    #[serde(default = "d_dim")]
    dim: f32,
    #[serde(default)]
    solid: bool,
}

fn d_dim() -> f32 { 0.55 }

pub struct App {
    screen: Screen,
    root: PathBuf,
    saved: Saved,
    pal: Pal,
    dirty: bool,
    manifest: Shared<Option<Result<Vec<VersionEntry>, String>>>,
    status: Shared<String>,
    busy: Arc<AtomicBool>,
    // create
    c_kind: usize, c_filter: String, picked: String, new_name: String, c_loader: usize,
    // library
    l_tab: usize, l_query: String,
    // discover
    d_query: String, d_type: usize, d_page: u32, d_results: Shared<Option<Result<Vec<Project>, String>>>,
    // controls
    layout: ControlLayout, sel: Option<usize>, json: String, msg: String,
    // settings
    s_tab: usize,
    // wallpaper
    wp_tex: Option<egui::TextureHandle>, wp_loaded: Option<usize>, thumbs: Vec<Option<egui::TextureHandle>>,
}

fn default_layout() -> ControlLayout {
    let b = |l: &str, x: f32, y: f32| ControlButton { label: l.into(), x, y, size: 56.0, key: l.to_lowercase() };
    ControlLayout {
        name: "My controls".into(),
        opacity: 0.8,
        buttons: vec![
            b("W", 18.0, 60.0), b("S", 18.0, 88.0), b("A", 8.0, 74.0), b("D", 28.0, 74.0),
            b("Jump", 88.0, 76.0), b("Sneak", 76.0, 88.0), b("Hit", 88.0, 48.0),
            b("Use", 74.0, 62.0), b("Bag", 50.0, 12.0),
        ],
    }
}

fn apply_visuals(ctx: &egui::Context, p: &Pal) {
    let mut v = egui::Visuals::dark();
    v.panel_fill = p.bg;
    v.window_fill = p.card;
    v.extreme_bg_color = p.card;
    v.override_text_color = Some(TEXT);
    v.selection.bg_fill = p.accent;
    v.hyperlink_color = p.accent2;
    v.widgets.inactive.weak_bg_fill = p.card;
    v.widgets.inactive.bg_fill = p.accent.gamma_multiply(0.4);
    v.widgets.hovered.weak_bg_fill = p.accent;
    v.widgets.active.weak_bg_fill = p.accent2;
    ctx.set_visuals(v);
    let mut st = (*ctx.style()).clone();
    st.spacing.button_padding = Vec2::new(12.0, 10.0);
    st.spacing.item_spacing = Vec2::new(10.0, 10.0);
    st.spacing.interact_size.y = 38.0;
    ctx.set_style(st);
}

fn logo(size: f32) -> egui::Image<'static> {
    egui::Image::from_bytes("bytes://alone-logo.png", include_bytes!("../../assets/logo.png"))
        .fit_to_exact_size(Vec2::splat(size))
        .rounding(size / 4.0)
}

fn card<R>(ui: &mut egui::Ui, p: &Pal, add: impl FnOnce(&mut egui::Ui) -> R) -> R {
    Frame::none()
        .fill(p.card.gamma_multiply(0.72))
        .stroke(Stroke::new(1.0, p.accent2.gamma_multiply(0.35)))
        .rounding(18.0)
        .inner_margin(14.0)
        .show(ui, |ui| { ui.set_width(ui.available_width()); add(ui) })
        .inner
}

fn tile(ui: &mut egui::Ui, p: &Pal, title: &str, sub: &str) -> bool {
    let r = Frame::none()
        .fill(p.card.gamma_multiply(0.72))
        .stroke(Stroke::new(1.0, p.accent2.gamma_multiply(0.35)))
        .rounding(18.0)
        .inner_margin(12.0)
        .show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.label(RichText::new(title).strong().size(16.0));
            ui.label(RichText::new(sub).small().color(p.accent2));
        });
    r.response.interact(Sense::click()).clicked()
}

fn big_btn(ui: &mut egui::Ui, text: &str, p: &Pal) -> egui::Response {
    ui.add_sized(
        [ui.available_width(), 48.0],
        egui::Button::new(RichText::new(text).size(18.0).strong().color(DARK)).fill(p.accent).rounding(24.0),
    )
}

fn caption(ui: &mut egui::Ui, p: &Pal, t: &str) {
    ui.label(RichText::new(t).small().strong().color(p.accent2));
}

fn rail_btn(ui: &mut egui::Ui, icon: &str, label: &str, on: bool, p: &Pal) -> egui::Response {
    let (rect, resp) = ui.allocate_exact_size(Vec2::new(76.0, 58.0), Sense::click());
    let fg = if on { DARK } else { Color32::WHITE };
    ui.painter().rect_filled(rect, 16.0, if on { p.accent } else { p.card.gamma_multiply(0.8) });
    ui.painter().rect_stroke(rect, 16.0, Stroke::new(1.0, p.accent2.gamma_multiply(0.5)));
    ui.painter().text(rect.center() - Vec2::new(0.0, 8.0), egui::Align2::CENTER_CENTER, icon, FontId::proportional(20.0), fg);
    ui.painter().text(rect.center() + Vec2::new(0.0, 16.0), egui::Align2::CENTER_CENTER, label, FontId::proportional(11.0), fg);
    resp
}

fn human(n: u64) -> String {
    if n >= 1_000_000 { format!("{}M", n / 1_000_000) } else if n >= 1000 { format!("{}K", n / 1000) } else { n.to_string() }
}

fn safe(s: &str) -> String {
    let t: String = s.chars().map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.' { c } else { '_' }).collect();
    if t.is_empty() { "instance".into() } else { t }
}

impl App {
    pub fn new(cc: &eframe::CreationContext<'_>, root: PathBuf) -> Self {
        egui_extras::install_image_loaders(&cc.egui_ctx);
        let mut saved: Saved = std::fs::read(root.join("state.json"))
            .ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
        if saved.user.is_empty() { saved.user = "Alone".into(); }
        if saved.ram_mb == 0 { saved.ram_mb = 1024; }
        if !root.join("state.json").exists() { saved.dim = d_dim(); }
        let pal = pal_of(saved.theme);
        let mut app = Self {
            screen: Screen::Home, root, saved, pal, dirty: true,
            manifest: Arc::new(Mutex::new(None)),
            status: Arc::new(Mutex::new("Nothing running".into())),
            busy: Arc::new(AtomicBool::new(false)),
            c_kind: 0, c_filter: String::new(), picked: String::new(), new_name: String::new(), c_loader: 0,
            l_tab: 0, l_query: String::new(),
            d_query: String::new(), d_type: 0, d_page: 0, d_results: Arc::new(Mutex::new(None)),
            layout: default_layout(), sel: None, json: String::new(), msg: String::new(),
            s_tab: 0,
            wp_tex: None, wp_loaded: None, thumbs: Vec::new(),
        };
        app.load_versions();
        app.search();
        app
    }

    /// Wallpaper (cover-cropped) with a dim layer, or a plain dark gradient.
    fn paint_bg(&mut self, ctx: &egui::Context) {
        let p = self.pal;
        let r = ctx.screen_rect();
        let painter = ctx.layer_painter(egui::LayerId::background());
        if !self.saved.solid {
            let want = self.saved.wallpaper.min(WALLPAPERS.len() - 1);
            if self.wp_loaded != Some(want) {
                self.wp_tex = decode_tex(ctx, &format!("wp{want}"), wp_full(want));
                self.wp_loaded = Some(want);
            }
            if let Some(t) = &self.wp_tex {
                let a = r.width() / r.height().max(1.0);
                let (u0, u1, v0, v1) = if a > 1.6 {
                    let h = 1.6 / a;
                    (0.0, 1.0, (1.0 - h) / 2.0, (1.0 + h) / 2.0)
                } else {
                    let w = a / 1.6;
                    ((1.0 - w) / 2.0, (1.0 + w) / 2.0, 0.0, 1.0)
                };
                painter.image(t.id(), r, Rect::from_min_max(Pos2::new(u0, v0), Pos2::new(u1, v1)), Color32::WHITE);
                painter.rect_filled(r, 0.0, Color32::from_black_alpha((self.saved.dim.clamp(0.0, 0.9) * 255.0) as u8));
                return;
            }
        }
        let n = 40;
        let h = r.height() / n as f32;
        for i in 0..n {
            let t = i as f32 / (n - 1) as f32;
            let mix = |a: u8, b: u8| (a as f32 + (b as f32 - a as f32) * t) as u8;
            let c = Color32::from_rgb(mix(p.bg.r(), p.bg2.r()), mix(p.bg.g(), p.bg2.g()), mix(p.bg.b(), p.bg2.b()));
            let top = r.top() + h * i as f32;
            painter.rect_filled(Rect::from_min_size(Pos2::new(r.left(), top), Vec2::new(r.width(), h + 1.0)), 0.0, c);
        }
    }

    fn save(&self) {
        let _ = std::fs::create_dir_all(&self.root);
        let _ = std::fs::write(self.root.join("state.json"), serde_json::to_vec_pretty(&self.saved).unwrap_or_default());
    }

    fn active(&self) -> Option<&Instance> { self.saved.active.and_then(|i| self.saved.instances.get(i)) }

    fn instance_dir(&self, i: &Instance) -> PathBuf { self.root.join("instances").join(safe(&i.name)) }

    fn set_status(&self, t: impl Into<String>) { *self.status.lock().unwrap() = t.into(); }

    fn load_versions(&self) {
        let m = self.manifest.clone();
        std::thread::spawn(move || { *m.lock().unwrap() = Some(versions::fetch_manifest().map(|m| m.versions)); });
    }

    fn search(&self) {
        let (res, q, t, off) = (self.d_results.clone(), self.d_query.clone(), DTYPES[self.d_type].1, self.d_page * 12);
        *res.lock().unwrap() = None;
        std::thread::spawn(move || { *res.lock().unwrap() = Some(modrinth::search(&q, t, off, 12)); });
    }

    /// Download and verify the files of Minecraft `mc` (client, libraries, assets).
    fn start_install(&self, mc: &str) {
        let entry = match &*self.manifest.lock().unwrap() {
            Some(Ok(v)) => v.iter().find(|e| e.id == mc).cloned(),
            _ => None,
        };
        let Some(entry) = entry else { self.set_status("Version list is still loading, try again in a moment"); return; };
        if self.busy.swap(true, Ordering::SeqCst) { return; }
        let (status, busy, root) = (self.status.clone(), self.busy.clone(), self.root.clone());
        std::thread::spawn(move || {
            *status.lock().unwrap() = format!("Preparing {}...", entry.id);
            let r = versions::fetch_meta(&entry).and_then(|m| {
                versions::install(&m, &root, &|d, t| { *status.lock().unwrap() = format!("Downloading {d}/{t}"); })
            });
            *status.lock().unwrap() = match r {
                Ok(()) => format!("{} is ready. Starting the game is not connected yet.", entry.id),
                Err(e) => format!("Failed: {e}"),
            };
            busy.store(false, Ordering::SeqCst);
        });
    }

    fn play(&self) {
        match self.active() {
            Some(i) => self.start_install(&i.mc.clone()),
            None => self.set_status("Create an instance first"),
        }
    }

    fn create_instance(&mut self) {
        if self.picked.is_empty() { self.set_status("Pick a Minecraft version first"); return; }
        let mc = self.picked.clone();
        let name = if self.new_name.trim().is_empty() { mc.clone() } else { self.new_name.trim().to_owned() };
        self.saved.instances.push(Instance { name, mc: mc.clone(), loader: LOADERS[self.c_loader].0.into(), pinned: false });
        self.saved.active = Some(self.saved.instances.len() - 1);
        self.save();
        self.start_install(&mc);
        self.new_name.clear();
        self.screen = Screen::Home;
    }

    fn install_project(&self, pr: Project) {
        let Some(inst) = self.active().cloned() else { self.set_status("Create or select an instance first"); return; };
        let (folder, loader) = match DTYPES[self.d_type].1 {
            "mod" => ("mods", inst.loader.to_lowercase()),
            "resourcepack" => ("resourcepacks", String::new()),
            _ => ("shaderpacks", String::new()),
        };
        if folder == "mods" && inst.loader == "Vanilla" {
            self.set_status("A Vanilla instance cannot load mods (mod loaders are not installable yet)");
            return;
        }
        let dir = self.instance_dir(&inst).join(folder);
        let (status, slug, mc) = (self.status.clone(), pr.slug.clone(), inst.mc.clone());
        std::thread::spawn(move || {
            *status.lock().unwrap() = format!("Installing {slug}...");
            *status.lock().unwrap() = match modrinth::install(&slug, &mc, &loader, &dir) {
                Ok(f) => format!("Installed {f}"),
                Err(e) => format!("Failed: {e}"),
            };
        });
    }

    // ---------- screens ----------
    fn rail(&mut self, ctx: &egui::Context) {
        let p = self.pal;
        egui::SidePanel::left("rail").exact_width(96.0)
            .frame(Frame::none().fill(Color32::from_black_alpha(110)).inner_margin(8.0))
            .show(ctx, |ui| {
                egui::ScrollArea::vertical().show(ui, |ui| {
                    ui.vertical_centered(|ui| {
                        ui.add(logo(52.0));
                        ui.label(RichText::new("ALONE").small().strong());
                        for (s, ic, l) in [
                            (Screen::Home, "🏠", "Home"), (Screen::Create, "➕", "Create new"),
                            (Screen::Library, "▦", "Library"), (Screen::Discover, "🔍", "Discover"),
                            (Screen::Themes, "🎨", "Themes"), (Screen::Controls, "🎮", "Controls"),
                            (Screen::Settings, "⚙", "Settings"),
                        ] {
                            if rail_btn(ui, ic, l, self.screen == s, &p).clicked() { self.screen = s; }
                        }
                    });
                });
            });
    }

    fn profile(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        ui.vertical_centered(|ui| {
            ui.add_space(8.0);
            ui.add(logo(160.0));
            ui.add(egui::TextEdit::singleline(&mut self.saved.user).horizontal_align(egui::Align::Center));
            let sub = self.active().map(|i| format!("{} {}", i.loader, i.mc)).unwrap_or_else(|| "No instance".into());
            ui.label(RichText::new(sub).color(p.accent2));
            if big_btn(ui, "PLAY  ▶", &p).clicked() { self.play(); }
        });
    }

    fn home(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        caption(ui, &p, "YOUR SPACE");
        let mut go = None;
        ui.columns(3, |c| {
            if tile(&mut c[0], &p, "Create instance", "Vanilla or modded") { go = Some(Screen::Create); }
            if tile(&mut c[1], &p, "Explore content", "Mods, packs, shaders") { go = Some(Screen::Discover); }
            if tile(&mut c[2], &p, "Your library", &format!("{} instance(s)", self.saved.instances.len())) { go = Some(Screen::Library); }
        });
        if let Some(s) = go { self.screen = s; }
        card(ui, &p, |ui| {
            caption(ui, &p, "ACTIVE INSTANCE");
            match self.active().cloned() {
                Some(i) => {
                    ui.label(RichText::new(&i.name).strong().size(20.0));
                    ui.label(RichText::new(format!("{} · Minecraft {}", i.loader, i.mc)).color(p.accent2));
                    if big_btn(ui, "▶  Play", &p).clicked() { self.play(); }
                }
                None => { ui.label("No instance yet. Open Create new to make one."); }
            }
        });
        card(ui, &p, |ui| {
            caption(ui, &p, "TASKS");
            ui.horizontal(|ui| {
                if self.busy.load(Ordering::SeqCst) { ui.spinner(); }
                ui.label(self.status.lock().unwrap().clone());
            });
        });
        card(ui, &p, |ui| {
            caption(ui, &p, "RECENT INSTANCES");
            let list: Vec<(usize, Instance)> = self.saved.instances.iter().cloned().enumerate().rev().take(3).collect();
            if list.is_empty() { ui.label("Nothing here yet."); }
            for (idx, i) in list {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(&i.name).strong());
                    ui.label(format!("{} {}", i.loader, i.mc));
                    if ui.button("Select").clicked() { self.saved.active = Some(idx); self.save(); }
                });
            }
        });
    }

    fn create(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        ui.heading("Create New Instance");
        let list: Vec<VersionEntry> = match &*self.manifest.lock().unwrap() { Some(Ok(v)) => v.clone(), _ => vec![] };
        let mut create = false;
        ui.columns(2, |c| {
            card(&mut c[0], &p, |ui| {
                ui.horizontal_wrapped(|ui| {
                    for (i, k) in KINDS.iter().enumerate() { ui.selectable_value(&mut self.c_kind, i, k.0); }
                });
                ui.add(egui::TextEdit::singleline(&mut self.c_filter).hint_text("Filter versions"));
                if list.is_empty() { ui.spinner(); }
                egui::ScrollArea::vertical().id_salt("vers").max_height(300.0).show(ui, |ui| {
                    for e in list.iter().filter(|e| e.kind == KINDS[self.c_kind].1 && e.id.contains(self.c_filter.trim())).take(300) {
                        if ui.selectable_label(self.picked == e.id, format!("Minecraft {}", e.id)).clicked() { self.picked = e.id.clone(); }
                    }
                });
            });
            card(&mut c[1], &p, |ui| {
                caption(ui, &p, "INSTANCE INFO");
                ui.label(format!("Version: {}", if self.picked.is_empty() { "none picked" } else { &self.picked }));
                ui.add(egui::TextEdit::singleline(&mut self.new_name).hint_text("Instance name"));
                caption(ui, &p, "LOADER");
                ui.horizontal_wrapped(|ui| {
                    for (i, (n, d, on)) in LOADERS.iter().enumerate() {
                        let t = if *on { format!("{n}\n{d}") } else { format!("{n}\nsoon") };
                        if ui.add_enabled(*on, egui::SelectableLabel::new(self.c_loader == i, t)).clicked() { self.c_loader = i; }
                    }
                });
                if big_btn(ui, "Create & Install Instance", &p).clicked() { create = true; }
            });
        });
        if create { self.create_instance(); }
    }

    fn library(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        ui.heading("Instance Management");
        ui.add(egui::TextEdit::singleline(&mut self.l_query).hint_text("Search instances...").desired_width(f32::INFINITY));
        ui.horizontal(|ui| {
            for (i, t) in ["All", "Modpacks", "Vanilla", "Pinned"].iter().enumerate() { ui.selectable_value(&mut self.l_tab, i, *t); }
        });
        let q = self.l_query.to_lowercase();
        let tab = self.l_tab;
        let shown: Vec<(usize, Instance)> = self.saved.instances.iter().cloned().enumerate()
            .filter(|(_, i)| i.name.to_lowercase().contains(&q))
            .filter(|(_, i)| match tab { 1 => i.loader != "Vanilla", 2 => i.loader == "Vanilla", 3 => i.pinned, _ => true })
            .collect();
        caption(ui, &p, &format!("YOUR INSTANCES · {} installed", self.saved.instances.len()));
        ui.horizontal_wrapped(|ui| {
            for (idx, i) in &shown {
                if ui.selectable_label(self.saved.active == Some(*idx), format!("{}\n{} {}", i.name, i.loader, i.mc)).clicked() {
                    self.saved.active = Some(*idx);
                    self.save();
                }
            }
        });
        if let Some(idx) = self.saved.active.filter(|i| *i < self.saved.instances.len()) {
            let i = self.saved.instances[idx].clone();
            card(ui, &p, |ui| {
                ui.label(RichText::new(&i.name).strong().size(20.0));
                ui.label(RichText::new(format!("{} · Minecraft {}", i.loader, i.mc)).color(p.accent2));
                ui.label(format!("Folder: {}", self.instance_dir(&i).display()));
                ui.horizontal_wrapped(|ui| {
                    if ui.button(if i.pinned { "Unpin" } else { "Pin" }).clicked() {
                        self.saved.instances[idx].pinned = !i.pinned;
                        self.save();
                    }
                    if ui.button("Delete").clicked() {
                        self.saved.instances.remove(idx);
                        self.saved.active = if self.saved.instances.is_empty() { None } else { Some(0) };
                        self.save();
                    }
                });
                if big_btn(ui, "▶  PLAY", &p).clicked() { self.play(); }
            });
        }
    }

    fn discover(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        let mut do_search = false;
        ui.horizontal(|ui| {
            ui.add(egui::TextEdit::singleline(&mut self.d_query).hint_text("Search...").desired_width((ui.available_width() - 440.0).max(80.0)));
            for (i, t) in DTYPES.iter().enumerate() {
                if ui.selectable_value(&mut self.d_type, i, t.0).clicked() { do_search = true; }
            }
            if ui.button("Search").clicked() { do_search = true; }
        });
        if do_search { self.d_page = 0; self.search(); }
        let state = self.d_results.lock().unwrap().clone();
        let mut install: Option<Project> = None;
        match state {
            None => { ui.spinner(); }
            Some(Err(e)) => { ui.colored_label(Color32::LIGHT_RED, e); }
            Some(Ok(list)) => {
                let cols = ((ui.available_width() / 300.0) as usize).max(1);
                for chunk in list.chunks(cols) {
                    ui.columns(cols, |c| {
                        for (i, pr) in chunk.iter().enumerate() {
                            card(&mut c[i], &p, |ui| {
                                ui.label(RichText::new(&pr.title).strong().size(17.0));
                                ui.label(format!("⬇ {}", human(pr.downloads)));
                                let d: String = pr.description.chars().take(90).collect();
                                ui.label(RichText::new(d).small());
                                ui.label(RichText::new(pr.categories.join(" · ")).small().color(p.accent2));
                                if big_btn(ui, "Install", &p).clicked() { install = Some(pr.clone()); }
                            });
                        }
                    });
                }
            }
        }
        ui.horizontal(|ui| {
            if ui.button("◀").clicked() && self.d_page > 0 { self.d_page -= 1; self.search(); }
            ui.label(format!("Page {}", self.d_page + 1));
            if ui.button("▶").clicked() { self.d_page += 1; self.search(); }
            ui.label(RichText::new(self.status.lock().unwrap().clone()).color(p.accent2));
        });
        if let Some(pr) = install { self.install_project(pr); }
    }

    fn themes(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        card(ui, &p, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label(RichText::new(format!("{} Minecraft Wallpapers", WALLPAPERS.len())).strong().size(18.0));
                if ui.add(egui::Slider::new(&mut self.saved.dim, 0.0..=0.9).text("Dim").trailing_fill(true)).changed() { self.save(); }
                if ui.selectable_label(self.saved.solid, "Solid Dark").clicked() {
                    self.saved.solid = !self.saved.solid;
                    self.save();
                }
            });
        });
        if self.thumbs.len() != WALLPAPERS.len() { self.thumbs = (0..WALLPAPERS.len()).map(|_| None).collect(); }
        let ctx = ui.ctx().clone();
        for i in 0..WALLPAPERS.len() {
            if self.thumbs[i].is_none() { self.thumbs[i] = decode_tex(&ctx, &format!("wpt{i}"), wp_thumb(i)); }
        }
        let ids: Vec<usize> = (0..WALLPAPERS.len()).collect();
        for row in ids.chunks(3) {
            ui.columns(3, |c| {
                for (k, &i) in row.iter().enumerate() {
                    let ui = &mut c[k];
                    let w = ui.available_width();
                    let mut clicked = false;
                    if let Some(t) = &self.thumbs[i] {
                        let img = egui::Image::new(egui::load::SizedTexture::new(t.id(), Vec2::new(w, w * 0.625)))
                            .rounding(14.0)
                            .sense(Sense::click());
                        let resp = ui.add(img);
                        if self.saved.wallpaper == i && !self.saved.solid {
                            ui.painter().rect_stroke(resp.rect, 14.0, Stroke::new(3.0, p.accent2));
                        }
                        clicked = resp.clicked();
                    }
                    ui.label(RichText::new(WALLPAPERS[i].0).strong());
                    ui.label(RichText::new(WALLPAPERS[i].1).small().color(p.accent2));
                    if clicked {
                        self.saved.wallpaper = i;
                        self.saved.solid = false;
                        self.save();
                    }
                }
            });
        }
    }

    fn settings(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        ui.horizontal_wrapped(|ui| {
            for (i, t) in STABS.iter().enumerate() { ui.selectable_value(&mut self.s_tab, i, *t); }
        });
        match self.s_tab {
            0 => card(ui, &p, |ui| {
                caption(ui, &p, "RENDERER BACKEND");
                for (i, (n, d)) in RENDERERS.iter().enumerate() {
                    if ui.selectable_label(self.saved.renderer == i, format!("{n}   {d}")).clicked() {
                        self.saved.renderer = i;
                        self.save();
                    }
                }
                ui.label("Saved now. It is used when starting the game is connected.");
            }),
            1 => card(ui, &p, |ui| {
                caption(ui, &p, "OFFLINE ACCOUNT");
                ui.label("Player name");
                if ui.add(egui::TextEdit::singleline(&mut self.saved.user).desired_width(260.0)).changed() { self.save(); }
                ui.label("No login needed. Used when starting the game is connected.");
            }),
            2 => card(ui, &p, |ui| {
                caption(ui, &p, "MEMORY");
                if ui.add(egui::Slider::new(&mut self.saved.ram_mb, 512..=6144).step_by(256.0).text("RAM (MB)").trailing_fill(true)).changed() { self.save(); }
                caption(ui, &p, "DEFAULT JRE");
                ui.horizontal_wrapped(|ui| {
                    for (v, l) in [(0u8, "Auto"), (25, "JRE 25"), (17, "JRE 17"), (8, "JRE 8"), (21, "JRE 21")] {
                        if ui.selectable_value(&mut self.saved.jre, v, l).clicked() { self.save(); }
                    }
                });
            }),
            3 => card(ui, &p, |ui| {
                caption(ui, &p, "LAUNCHER");
                if ui.button("Open Themes").clicked() { self.screen = Screen::Themes; }
                if ui.button("Open Controls editor").clicked() { self.screen = Screen::Controls; }
                ui.label(format!("Game folder: {}", self.root.display()));
            }),
            _ => card(ui, &p, |ui| {
                caption(ui, &p, "ABOUT");
                ui.label("ALONE LAUNCHER v0.1, written in Rust.");
                ui.label("Minecraft files come from Mojang; mods from Modrinth.");
            }),
        }
    }

    fn controls_tab(&mut self, ui: &mut egui::Ui) {
        let p = self.pal;
        ui.heading("Custom controls");
        let w = ui.available_width().min(760.0);
        let (rect, _) = ui.allocate_exact_size(Vec2::new(w, w * 0.45), Sense::hover());
        ui.painter().rect_filled(rect, 12.0, p.card);
        ui.painter().rect_stroke(rect, 12.0, Stroke::new(2.0, p.accent));
        for i in 0..self.layout.buttons.len() {
            let (bx, by, bs, label) = { let b = &self.layout.buttons[i]; (b.x, b.y, b.size, b.label.clone()) };
            let c = Pos2::new(rect.left() + rect.width() * bx / 100.0, rect.top() + rect.height() * by / 100.0);
            let r = ui.interact(Rect::from_center_size(c, Vec2::splat(bs)), egui::Id::new(("cb", i)), Sense::click_and_drag());
            if r.dragged() {
                let d = r.drag_delta();
                let b = &mut self.layout.buttons[i];
                b.x = (b.x + d.x / rect.width() * 100.0).clamp(0.0, 100.0);
                b.y = (b.y + d.y / rect.height() * 100.0).clamp(0.0, 100.0);
            }
            if r.clicked() || r.drag_started() { self.sel = Some(i); }
            let col = if self.sel == Some(i) { p.accent2 } else { p.accent };
            ui.painter().circle_filled(c, bs / 2.0, col.gamma_multiply(self.layout.opacity));
            ui.painter().text(c, egui::Align2::CENTER_CENTER, label, FontId::proportional(13.0), Color32::WHITE);
        }
        ui.label("Drag a button to move it. Tap one to select it.");
        if let Some(i) = self.sel.filter(|i| *i < self.layout.buttons.len()) {
            ui.add(egui::Slider::new(&mut self.layout.buttons[i].size, 20.0..=160.0).text("Size"));
        }
        ui.add(egui::Slider::new(&mut self.layout.opacity, 0.2..=1.0).text("Opacity"));
        ui.horizontal_wrapped(|ui| {
            if ui.button("Add button").clicked() {
                self.layout.buttons.push(ControlButton { label: "New".into(), x: 50.0, y: 50.0, size: 56.0, key: String::new() });
                self.sel = Some(self.layout.buttons.len() - 1);
            }
            if ui.button("Delete selected").clicked() {
                if let Some(i) = self.sel.take().filter(|i| *i < self.layout.buttons.len()) { self.layout.buttons.remove(i); }
            }
            if ui.button("Reset").clicked() { self.layout = default_layout(); self.sel = None; }
        });
        ui.separator();
        if ui.button("Save layout").clicked() {
            self.msg = match controls::save(&self.root.join("controls"), &self.layout) {
                Ok(p) => format!("Saved {}", p.display()),
                Err(e) => format!("Save failed: {e}"),
            };
        }
        for n in controls::list(&self.root.join("controls")) {
            if ui.button(format!("Load: {n}")).clicked() {
                match controls::load(&self.root.join("controls"), &n) {
                    Ok(l) => { self.layout = l; self.sel = None; self.msg = format!("Loaded {n}"); }
                    Err(e) => self.msg = e,
                }
            }
        }
        if !self.msg.is_empty() { ui.label(RichText::new(&self.msg).color(p.accent2)); }
    }
}

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _f: &mut eframe::Frame) {
        if self.dirty { apply_visuals(ctx, &self.pal); self.dirty = false; }
        self.paint_bg(ctx);
        ctx.request_repaint_after(std::time::Duration::from_millis(250));
        self.rail(ctx);
        if self.screen == Screen::Home && ctx.screen_rect().width() > 900.0 {
            egui::SidePanel::right("profile").exact_width(280.0)
                .frame(Frame::none().inner_margin(10.0))
                .show(ctx, |ui| self.profile(ui));
        }
        egui::CentralPanel::default().frame(Frame::none().inner_margin(12.0)).show(ctx, |ui| {
            egui::ScrollArea::vertical().auto_shrink([false, false]).show(ui, |ui| match self.screen {
                Screen::Home => self.home(ui),
                Screen::Create => self.create(ui),
                Screen::Library => self.library(ui),
                Screen::Discover => self.discover(ui),
                Screen::Themes => self.themes(ui),
                Screen::Controls => self.controls_tab(ui),
                Screen::Settings => self.settings(ui),
            });
        });
    }
}
